import yt_dlp, asyncio, os, uuid, subprocess, shutil, random
from config import Config, STATUS_OK, STATUS_FAIL
from logger import log

# User Agent Random (Opsional, yt-dlp sebenarnya sudah punya, tapi kita bantu biar fresh)
UAS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
]

async def run_audio_engine(url: str, output_path: str):
    loop = asyncio.get_running_loop()
    request_id = str(uuid.uuid4())[:8]
    raw_dir = os.path.join(Config.RAW_DIR, request_id)
    os.makedirs(raw_dir, exist_ok=True)
    
    # --- 1. SETUP COOKIES & UA ---
    cookie_file = None
    for cf in Config.COOKIES_FILES:
        p = os.path.join(Config.BASE_DIR, cf)
        if os.path.exists(p):
            cookie_file = p; break
    
    # --- 2. CONFIG YTDLP (MURNI) ---
    # Kita tidak memaksa format 'm4a' atau 'webm'.
    # Kita minta 'bestaudio'. Jika tidak ada, 'best' (video+audio) pun diambil.
    ydl_opts = {
        "format": "bestaudio/best", 
        "outtmpl": os.path.join(raw_dir, "%(id)s.%(ext)s"),
        "quiet": True, 
        "no_warnings": True, 
        "ignoreerrors": True, # Lanjut jika ada error kecil
        "nocheckcertificate": True,
        "user_agent": random.choice(UAS),
        
        # Network Optimization
        "socket_timeout": 30,
        "retries": 10,
        "fragment_retries": 10,
    }
    
    if cookie_file: ydl_opts["cookiefile"] = cookie_file

    try:
        # --- 3. DOWNLOAD PROCESS ---
        def _download():
            with yt_dlp.YoutubeDL(ydl_opts) as ydl: return ydl.extract_info(url, download=True)
        info = await loop.run_in_executor(None, _download)
        
        # Validasi Hasil Download
        raw_files = os.listdir(raw_dir)
        if not raw_files: 
            # Fallback: Mungkin video pendek/shorts butuh penanganan lain, tapi biasanya bestaudio cover semua.
            raise Exception("yt-dlp did not download any file")
            
        raw_path = os.path.join(raw_dir, raw_files[0])
        
        # Metadata
        title = info.get("title", f"audio-{request_id}")
        safe_title = "".join(c for c in title if c.isalnum() or c in " -_").strip()[:50]
        final_path = os.path.join(Config.TMP_DIR, f"{safe_title}.mp3")
        
        # --- 4. FFMPEG CONVERSION (THE HARD WORKER) ---
        # Apapun yang didapat (WebM, M4A, MP4), ubah paksa jadi MP3
        ffmpeg_bin = os.path.join(Config.BASE_DIR, "ffmpeg-master-latest-linux64-gpl", "bin", "ffmpeg")
        if not os.path.exists(ffmpeg_bin): ffmpeg_bin = "ffmpeg"
        
        cmd = [
            ffmpeg_bin, "-y", 
            "-i", raw_path, 
            "-vn", # Buang Video (jika ada)
            "-map_metadata", "-1",
            "-acodec", "libmp3lame", 
            "-ab", "128k", 
            "-ar", "44100", 
            "-ac", "2",
            "-threads", "0", 
            "-preset", "ultrafast", 
            final_path
        ]
        
        process = await asyncio.create_subprocess_exec(*cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        await process.wait()
        
        # Cek hasil akhir
        if not os.path.exists(final_path) or os.path.getsize(final_path) < 1000: 
            raise Exception("FFmpeg conversion failed")
            
        # Bersih-bersih
        shutil.rmtree(raw_dir, ignore_errors=True)
        
        return {
            "status": STATUS_OK, 
            "engine": "Engine A (Audio/Pure)", 
            "filename": os.path.basename(final_path),
            "title": title, 
            "thumbnail": info.get("thumbnail"), 
            "duration": info.get("duration_string"),
            "author": info.get("uploader"), 
            "request_id": request_id
        }
    except Exception as e:
        shutil.rmtree(raw_dir, ignore_errors=True)
        return {"status": STATUS_FAIL, "reason": str(e)}
